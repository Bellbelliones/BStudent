import "./style.css"

export const NavigationMenu = () =>{
    return (
        <>
            <div className="navigation flex jc-spacebetween fd-row">
                <div className="flex jc-center ai-center ml">
                    <button>
                        <img src="Ícone de menu hambúrguer minimalista.png" alt="" />
                    </button>
                    <img className="logo" src="Logótipo BStudent com Capelo Académico.png" alt="" />
                    <h4>B<span>Student</span></h4>
                </div>
                <div className="mr">
                    <button>
                        <img className="myPhoto" src="images.jpeg" alt="" />
                    </button>
                </div>
            </div>
        </>
    )
}